# Tucil 2 StiMa : Divide and Conqer Perkalian Polinom
Michel Fang / 13518137 / K2

## Prerequisites
1. C++

## Struktur Folder
```
├── run.bat
├── README.md
├── bin
│   ├── a.exe
└── src
    ├── Polinom.hpp
    ├── PolinomBF.hpp
    ├── Polinom.DnC
    └── main.cpp
```
1. bin berisi executable dari program
2. src berisi kode program

## Compile dan Run
```
./run.sh
```

Masukkan program berupa ```n```, yaitu derajat polinom, lalu koefisien polinom akan dibangkitkan secara acak. Setelah itu, pengguna dapat memilih untuk menampilkan hasil perkalian atau tidak.